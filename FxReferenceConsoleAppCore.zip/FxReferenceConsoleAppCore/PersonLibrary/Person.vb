﻿Public Class Person
    Public Property FirstName() As String
    Public Property LastName() As String
    Public Property DateOfBirth() As DateTime

    'Sub New()

    'End Sub
    'Sub New(_firstName As String, _lastName As String, _dateOfBirth As DateTime)
    '    FirstName = _firstName
    '    LastName = _lastName
    '    If IsDate(_dateOfBirth) Then
    '        DateOfBirth = _dateOfBirth
    '    End If
    'End Sub
End Class
